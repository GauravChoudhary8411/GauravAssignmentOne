package com.example.gaurav_assignmentone;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.UUID;

public class Profile extends AppCompatActivity {
    ImageView iv;
    Button upload, placement;
    TextView textView;
    FirebaseStorage fs = FirebaseStorage.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        iv = findViewById(R.id.profile_photo);
        upload = findViewById(R.id.upload);
        placement = findViewById(R.id.placement);
        textView = findViewById(R.id.Welcome);
        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(i, 1);
            }
        });

        placement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Placement.class);
                startActivity(i);
            }
        });

        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iv.setDrawingCacheEnabled(true);
                iv.buildDrawingCache();
                Bitmap b = iv.getDrawingCache();
                ByteArrayOutputStream ba = new ByteArrayOutputStream();
                b.compress(Bitmap.CompressFormat.PNG, 100, ba);
                iv.setDrawingCacheEnabled(false);
                byte[] bt = ba.toByteArray();
                String path = "firstFolder/" + UUID.randomUUID();
                StorageReference ref = fs.getReference(path);
                StorageMetadata md = new StorageMetadata.Builder()
                        .setCustomMetadata("text", textView.getText()
                                .toString()).build();
                upload.setEnabled(false);
                UploadTask ut = ref.putBytes(bt, md);
                ut.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        upload.setEnabled(true);
                        Task<Uri> url = taskSnapshot.getMetadata().getReference()
                                .getDownloadUrl();
                        textView.setText(url.toString());
                        Toast.makeText(getApplicationContext(),"Photo Uploaded Successfully",Toast.LENGTH_SHORT).show();

                    }
                });
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            if (data.getData() != null) {
                Uri uri = data.getData();
                iv.setImageURI(uri);
                Toast.makeText(getApplicationContext(),"Photo Selected Successfully",Toast.LENGTH_SHORT).show();
            }
        }
    }
}
package com.example.gaurav_assignmentone;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Placement extends AppCompatActivity {
    TextView a, b, c, e;
    Button read;
    public FirebaseAuth fa;
    DatabaseReference d;
    ListView lv1;
    List<company> companyList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_placement);
        d = FirebaseDatabase.getInstance().getReference();
        fa = FirebaseAuth.getInstance();
        a = findViewById(R.id.reg_no);
        b = findViewById(R.id.name);
        c = findViewById(R.id.roll_no);
        e = findViewById(R.id.cgpa);
        read = findViewById(R.id.read);
        companyList = new ArrayList<>();
        lv1 = findViewById(R.id.lv);
        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d = FirebaseDatabase.getInstance().getReference().child("Student").child("Gaurav");
                d.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot datasnapshot) {
                        String name = datasnapshot.child("name").getValue().toString();
                        String reg = datasnapshot.child("reg").getValue().toString();
                        String roll = datasnapshot.child("roll").getValue().toString();
                        String cgpa = datasnapshot.child("cgpa").getValue().toString();
                        a.setText("Registration No.: - "+reg);
                        b.setText("Name: - "+name);
                        c.setText("Roll No.: - "+roll);
                        e.setText("CGPA: - "+cgpa);
                        float cg = Float.parseFloat(cgpa);
                        if (cg > 6.6) {
                            Toast.makeText(getApplicationContext(), "You are eligible for placements", Toast.LENGTH_LONG).show();
                            companyList.add(new company(R.drawable.adobe, "Adobe", "CTC: - 32L"));
                            companyList.add(new company(R.drawable.amazon, "Amazon", "CTC: - 52L"));
                            companyList.add(new company(R.drawable.cognizant, "Cognizant", "CTC: - 3.2L"));
                            companyList.add(new company(R.drawable.ubisoft, "Ubisoft", "CTC: - 65.2L"));
                            companyList.add(new company(R.drawable.ea_sports, "EA Sports", "CTC: - 1.2Cr."));
                            companyList.add(new company(R.drawable.hexaware, "Hexaware", "CTC: - 10.8L"));
                            companyList.add(new company(R.drawable.iw, "Infinity Ward", "CTC: - 1Cr."));
                            companyList.add(new company(R.drawable.capgemini, "Capgemini", "CTC: - 5.2L"));
                            companyList.add(new company(R.drawable.microsoft, "Microsoft", "CTC: - 42L"));
                            MyListAdapter adapter = new MyListAdapter(getApplicationContext(), R.layout.mylist, companyList);
                            lv1.setAdapter(adapter);
                        }
                        if (cg <= 6.6) {
                            Toast.makeText(getApplicationContext(), "Improve your grades to be eligible for Placements", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
            }
        });

    }
}
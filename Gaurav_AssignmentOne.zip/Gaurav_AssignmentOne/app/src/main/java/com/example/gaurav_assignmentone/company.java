package com.example.gaurav_assignmentone;

class company {
    int image;
    String cname, salary;

    public company(int image, String cname, String salary) {
        this.image = image;
        this.cname = cname;
        this.salary = salary;
    }

    public int getImage() {
        return image;
    }

    public String getCname() {
        return cname;
    }

    public String getSalary() {
        return salary;
    }
}

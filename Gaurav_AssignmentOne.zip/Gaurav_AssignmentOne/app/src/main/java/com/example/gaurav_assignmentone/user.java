package com.example.gaurav_assignmentone;

public class user {
    public String reg, name, roll, cgpa;

    user(String a, String b, String c, String d) {
        reg = a;
        name = b;
        roll = c;
        cgpa = d;
    }
}
package com.example.gaurav_assignmentone;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

class MyListAdapter extends ArrayAdapter<company> {
    List<company> companyList;
    Context context;
    int resource;

    public MyListAdapter(Context context, int resource, List<company> companyList) {
        super(context, resource, companyList);
        this.context = context;
        this.resource = resource;
        this.companyList = companyList;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);

        View view = layoutInflater.inflate(resource, null, false);
        ImageView imageView = view.findViewById(R.id.company);
        TextView textViewName = view.findViewById(R.id.companyname);
        TextView textViewpackadge = view.findViewById(R.id.packadge);

        company company = companyList.get(position);

        imageView.setImageDrawable(context.getResources().getDrawable(company.getImage()));
        textViewName.setText(company.getCname());
        textViewpackadge.setText(company.getSalary());

        return view;
    }
}

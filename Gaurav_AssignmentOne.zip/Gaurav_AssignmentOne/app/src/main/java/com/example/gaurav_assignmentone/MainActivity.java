package com.example.gaurav_assignmentone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    public EditText reg_no, names, roll_no, cgpa;
    Button save;
    public FirebaseAuth fa;
    public DatabaseReference d;
    user u;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        d = FirebaseDatabase.getInstance().getReference();
        fa = FirebaseAuth.getInstance();
        reg_no = findViewById(R.id.reg_no);
        names = findViewById(R.id.name);
        roll_no = findViewById(R.id.roll_no);
        cgpa = findViewById(R.id.cgpa);
        save = findViewById(R.id.save);
    }

    @Override
    public void onClick(View view) {
        if(cgpa.getText().toString().isEmpty()||roll_no.getText().toString().isEmpty()||names.getText().toString().isEmpty()||reg_no.getText().toString().isEmpty()){
            Toast.makeText(getApplicationContext(),"Enter all the details to proceed further",Toast.LENGTH_SHORT).show();
        }
        else {
            u = new user(reg_no.getText().toString(), names.getText().toString(), roll_no.getText().toString(), cgpa.getText().toString());
            d.child("Student").child("Gaurav").setValue(u);
            Toast.makeText(getApplicationContext(), "Data is Saved Sucessfully", Toast.LENGTH_LONG).show();
            Intent i = new Intent(getApplicationContext(), Profile.class);
            startActivity(i);
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
